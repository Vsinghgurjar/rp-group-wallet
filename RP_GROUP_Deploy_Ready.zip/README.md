# RP GROUP Wallet — Deploy-ready starter

## Included
- Node.js + Express backend
- SQLite database
- Password hashing with bcrypt
- JWT login
- Server-side wallet ledger
- Transaction history
- Rate limiting + Helmet
- Admin API for controlled demo credits/debits
- Mobile-friendly frontend

## Local run
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Set a long random `JWT_SECRET` and a strong `ADMIN_KEY`.
4. Install: `npm install`
5. Start: `npm start`
6. Open `http://localhost:3000`

## Deployment
Use any Node.js hosting that supports a persistent filesystem (or replace SQLite
with a managed PostgreSQL/MySQL database). Set the environment variables from
`.env.example`, run `npm install`, then `npm start`. Put the app behind HTTPS.

## Important
This project intentionally has NO real-money deposit/withdrawal, UPI, bank transfer,
USDT, investment, or guaranteed-return functionality. Wallet values are stored in
integer paise on the server. Before any real-money feature is added, obtain the
required legal/compliance review and use a compliant payment provider.

For production, also add:
- managed database + backups
- email/SMS OTP
- password reset
- proper admin login/RBAC
- HTTPS-only cookies or short-lived access tokens + refresh-token rotation
- monitoring, alerts and audit retention
- validation and fraud/risk controls
