Admin API
=========
Use the X-Admin-Key header with the ADMIN_KEY from your environment.

GET  /api/admin/users
POST /api/admin/credit {"userId":"RP123456","amount":1000,"note":"Demo credit"}
POST /api/admin/debit  {"userId":"RP123456","amount":1000,"note":"Demo debit"}

IMPORTANT: amount is in paise, so ₹10.00 = 1000.
For production, put admin operations behind proper admin authentication,
HTTPS, role-based authorization, CSRF protection where applicable,
and an audit/review workflow. Do not expose ADMIN_KEY in frontend code.
