import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, "..");
const app = express();
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"50kb"}));
app.use(rateLimit({windowMs:15*60*1000,max:300}));
app.use(express.static(path.join(root,"public")));

const db = new Database(process.env.DB_FILE || path.join(root,"database/rp-group.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id TEXT UNIQUE NOT NULL,
 name TEXT NOT NULL,
 phone TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 pin_hash TEXT,
 balance INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS transactions(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 type TEXT NOT NULL CHECK(type IN ('credit','debit')),
 amount INTEGER NOT NULL CHECK(amount > 0),
 note TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS audit_logs(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 action TEXT NOT NULL,
 user_id INTEGER,
 note TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`);

const JWT_SECRET = process.env.JWT_SECRET || "DEV_ONLY_CHANGE_ME";
const ADMIN_KEY = process.env.ADMIN_KEY || "DEV_ADMIN_CHANGE_ME";

function auth(req,res,next){
  try{
    const token=(req.headers.authorization||"").replace(/^Bearer /,"");
    req.user=jwt.verify(token,JWT_SECRET);
    next();
  }catch{res.status(401).json({error:"Unauthorized"});}
}
function uid(){return "RP"+Math.floor(100000+Math.random()*900000);}
function publicUser(u){return {userId:u.user_id,name:u.name,phone:u.phone,balance:u.balance};}

const register = db.prepare("INSERT INTO users(user_id,name,phone,password_hash) VALUES(?,?,?,?)");
app.post("/api/register", async (req,res)=>{
  const {name,phone,password}=req.body||{};
  if(!name||!phone||typeof password!=="string"||password.length<6) return res.status(400).json({error:"Name, phone and password (6+ chars) required"});
  try{
    const hash=await bcrypt.hash(password,12);
    const id=uid(); const info=register.run(id,name.trim(),phone.trim(),hash);
    res.json({ok:true,userId:id});
  }catch(e){res.status(409).json({error:"Phone already registered"});}
});

app.post("/api/login", async (req,res)=>{
  const {phone,password}=req.body||{};
  const u=db.prepare("SELECT * FROM users WHERE phone=?").get(phone?.trim());
  if(!u || !(await bcrypt.compare(password||"",u.password_hash))) return res.status(401).json({error:"Invalid login"});
  const token=jwt.sign({id:u.id,userId:u.user_id},JWT_SECRET,{expiresIn:"7d"});
  res.json({token,user:publicUser(u)});
});

app.get("/api/me",auth,(req,res)=>{
  const u=db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
  if(!u)return res.status(404).json({error:"User not found"});
  res.json(publicUser(u));
});
app.get("/api/transactions",auth,(req,res)=>{
  res.json(db.prepare("SELECT type,amount,note,created_at FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 100").all(req.user.id));
});

const credit = db.transaction((userId,amount,note)=>{
  db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(amount,userId);
  db.prepare("INSERT INTO transactions(user_id,type,amount,note) VALUES(?,?,?,?)").run(userId,"credit",amount,note);
  db.prepare("INSERT INTO audit_logs(action,user_id,note) VALUES(?,?,?)").run("credit",userId,note);
});
const debit = db.transaction((userId,amount,note)=>{
  const u=db.prepare("SELECT balance FROM users WHERE id=?").get(userId);
  if(!u || u.balance<amount) throw new Error("Insufficient balance");
  db.prepare("UPDATE users SET balance=balance-? WHERE id=?").run(amount,userId);
  db.prepare("INSERT INTO transactions(user_id,type,amount,note) VALUES(?,?,?,?)").run(userId,"debit",amount,note);
  db.prepare("INSERT INTO audit_logs(action,user_id,note) VALUES(?,?,?)").run("debit",userId,note);
});

function admin(req,res,next){
  if(req.headers["x-admin-key"]!==ADMIN_KEY)return res.status(403).json({error:"Forbidden"});
  next();
}
app.post("/api/admin/credit",admin,(req,res)=>{
  const {userId,amount,note="Admin credit"}=req.body||{};
  if(!Number.isInteger(amount)||amount<=0)return res.status(400).json({error:"Amount must be a positive integer (paise)"});
  const u=db.prepare("SELECT id FROM users WHERE user_id=?").get(userId);
  if(!u)return res.status(404).json({error:"User not found"});
  credit(u.id,amount,note); res.json({ok:true});
});
app.post("/api/admin/debit",admin,(req,res)=>{
  const {userId,amount,note="Admin debit"}=req.body||{};
  if(!Number.isInteger(amount)||amount<=0)return res.status(400).json({error:"Amount must be a positive integer (paise)"});
  const u=db.prepare("SELECT id FROM users WHERE user_id=?").get(userId);
  if(!u)return res.status(404).json({error:"User not found"});
  try{debit(u.id,amount,note);res.json({ok:true});}catch{res.status(400).json({error:"Insufficient balance"});}
});
app.get("/api/admin/users",admin,(req,res)=>{
  res.json(db.prepare("SELECT user_id,name,phone,balance,created_at FROM users ORDER BY id DESC").all());
});

app.get("*",(req,res)=>res.sendFile(path.join(root,"public/index.html")));
const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`RP GROUP running on port ${port}`));
